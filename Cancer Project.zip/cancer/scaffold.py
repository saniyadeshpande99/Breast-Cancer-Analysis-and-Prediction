from django_plotly_dash import DjangoDash
from django.utils.module_loading import import_string

def stateless_app_loader(app_name):
	
	return import_string("cancer.scaffold." + app_name)

demo_app = DjangoDash(name="app_name")