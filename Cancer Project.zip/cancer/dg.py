import dash
import dash_core_components as dcc
import dash_html_components as html
from django_plotly_dash import DjangoDash
from dash.dependencies import Output,Input
import pandas as pd
import numpy as np

app = DjangoDash('Graph_module')

dd=pd.read_csv("H:\Project\mini\cancer\\new_data.csv")

df2=dd[dd.radius_mean>8]
df3=dd[dd.radius_mean>=11]
df4=dd[dd.radius_mean>=12]
df5=dd[dd.radius_mean>=13]
df6=dd[dd.radius_mean>=14]
df7=dd[dd.radius_mean>=15]
df8=dd[dd.radius_mean>=16]
df9=dd[dd.radius_mean>=17]
df10=dd[dd.radius_mean>=18]
df11=dd[dd.radius_mean>=19]
df12=dd[dd.radius_mean>=20]

objects = ('0-11','11-11.99','12-12.99','13-13.99','14-14.99','15-15.99','16-16.99','17-17.99','18-18.99','19-19.99','>20')
y_pos = np.arange(len(objects))
performance = [len(df2),len(df3),len(df4),len(df5),len(df6),len(df7),len(df8),len(df9),len(df10),len(df11),len(df12)]

app.layout = html.Div([

    html.Div([

                dcc.Graph(
                            id="bar_radius",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'bar'},],
                                'layout':{'title':'Radius_Bar!',
                                    'xaxis':{
                                        'title':'Radius Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        
        dcc.Graph(
                            id="pie_radius",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','labels':objects,'title':'Radius Mean',},],
                                'layout':{},
                                'legend':{'x':0,'y':1}
                            
                            }  
                        ),
    ]),

     html.Div([

                dcc.Graph(
                            id="bar_radius",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'line'},],
                                'layout':{'title':'Radius_Bar!',
                                    'xaxis':{
                                        'title':'Radius Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        dcc.Graph(
                            id="donut_radius",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','hole':0.7,'labels':objects,'title':'Radius Mean',},],
                                'layout':{},
                                'legend':{'x':objects,'y':1}
                            }
                        ),
    ]),    

    html.Div([

                dcc.Graph(
                            id="bar_radius",
                            
                            figure={
                                'data':[{'x':performance,
                                'y':objects,
                                'name':'xyz',
                                'orientation':'h',
                                'type':'bar'},],
                                'layout':{'title':'Radius_Bar!',
                                    'xaxis':{
                                        'title':'Number of Patients'
                                    },
                                    'yaxis':{
                                        'title':'Radius Mean'
                                    }}
                            }
                            
                        ),
            ]),        

])



