import dash
import dash_core_components as dcc
import dash_html_components as html
from django_plotly_dash import DjangoDash
from dash.dependencies import Output,Input
import pandas as pd
import numpy as np

app = DjangoDash('Graph_perimeter')

dd=pd.read_csv("H:\Project\mini\cancer\\new_data.csv")

peri1=dd[dd.perimeter_mean<60]
peri2=dd[dd.perimeter_mean>=75]
peri3=dd[dd.perimeter_mean>=90]
peri4=dd[dd.perimeter_mean>=105]
peri5=dd[dd.perimeter_mean>=120]
peri6=dd[dd.perimeter_mean>=135]
peri7=dd[dd.perimeter_mean>=150]

objects='<60','60-75','75-90','90-105','105-120','120-135','135-150'
performance=[len(peri1),len(peri2),len(peri3),len(peri4),len(peri5),len(peri6),len(peri7)]
colors=['red','blue','maroon']

app.layout = html.Div([

    html.Div([

                dcc.Graph(
                            id="bar_perimeter",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'bar'},],
                                'layout':{'title':'Perimeter_Bar!',
                                    'xaxis':{
                                        'title':'Perimeter Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        
        dcc.Graph(
                            id="pie_perimeter",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','labels':objects,'title':'Perimeter Mean',},],
                                'layout':{},
                                'legend':{'x':0,'y':1}
                            
                            }  
                        ),
    ]),

     html.Div([

                dcc.Graph(
                            id="bar_perimeter",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'line'},],
                                'layout':{'title':'Perimeter_Bar!',
                                    'xaxis':{
                                        'title':'Perimeter Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        dcc.Graph(
                            id="donut_perimeter",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','hole':0.7,'labels':objects,'title':'Perimeter Mean',},],
                                'layout':{},
                                'legend':{'x':objects,'y':1}
                            }
                        ),
    ]),       

    html.Div([

                dcc.Graph(
                            id="bar_perimeter",
                            
                            figure={
                                'data':[{'x':performance,
                                'y':objects,
                                'name':'xyz',
                                'orientation':'h',
                                'type':'bar'},],
                                'layout':{'title':'Perimeter_Bar!',
                                    'xaxis':{
                                        'title':'Number of Patients'
                                    },
                                    'yaxis':{
                                        'title':'Perimeter Mean'
                                    }}
                            }
                            
                        ),
            ]),     

])

