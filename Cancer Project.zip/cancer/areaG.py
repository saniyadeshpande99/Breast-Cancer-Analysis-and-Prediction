import dash
import dash_core_components as dcc
import dash_html_components as html
from django_plotly_dash import DjangoDash
from dash.dependencies import Output,Input
import pandas as pd
import numpy as np

app = DjangoDash('Graph_area')

dd=pd.read_csv("H:\Project\mini\cancer\\new_data.csv")

area1=dd[dd.area_mean<200]
area2=dd[dd.area_mean>=400]
area3=dd[dd.area_mean>=600]
area4=dd[dd.area_mean>=800]
area5=dd[dd.area_mean>=1000]
area6=dd[dd.area_mean>=1200]
area7=dd[dd.area_mean>=1400]
area8=dd[dd.area_mean>=1600]

objects='0-200','201-400','401-600','601-800','801-1000','1001-1200','1201-1400','1401-1600'
performance=[len(area1),len(area2),len(area3),len(area4),len(area5),len(area6),len(area7),len(area8)]
colors=['yellowgreen','lightcoral','lightskyblue','red','black','blue','maroon']

app.layout = html.Div([

    html.Div([

                dcc.Graph(
                            id="bar_area",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'bar'},],
                                'layout':{'title':'Area_Bar!',
                                    'xaxis':{
                                        'title':'Area Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        
        dcc.Graph(
                            id="pie_area",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','labels':objects,'title':'Area Mean',},],
                                'layout':{},
                                'legend':{'x':0,'y':1}
                            
                            }  
                        ),
    ]),

     html.Div([

                dcc.Graph(
                            id="bar_area",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'line'},],
                                'layout':{'title':'Area_Bar!',
                                    'xaxis':{
                                        'title':'Area Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        dcc.Graph(
                            id="donut_area",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','hole':0.7,'labels':objects,'title':'Area Mean',},],
                                'layout':{},
                                'legend':{'x':objects,'y':1}
                            }
                        ),
    ]),  

    html.Div([

                dcc.Graph(
                            id="bar_area",
                            
                            figure={
                                'data':[{'x':performance,
                                'y':objects,
                                'name':'xyz',
                                'orientation':'h',
                                'type':'bar'},],
                                'layout':{'title':'Area_Bar!',
                                    'xaxis':{
                                        'title':'Number of Patients'
                                    },
                                    'yaxis':{
                                        'title':'Area Mean'
                                    }}
                            }
                            
                        ),
            ]),     

])

