import dash
import dash_core_components as dcc
import dash_html_components as html
from django_plotly_dash import DjangoDash
from dash.dependencies import Output,Input
import pandas as pd
import numpy as np

app = DjangoDash('Graph_category')

dd=pd.read_csv("H:\Project\mini\cancer\\new_data.csv")

diag1=dd[dd.diagnosis=='M']
diag2=dd[dd.diagnosis=='B']

objects='malignant(C)','benign(NC)'
performance=[len(diag1),len(diag2)]
colors=['yellowgreen','lightcoral']

app.layout = html.Div([

    html.Div([

                dcc.Graph(
                            id="bar_category",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'bar'},],
                                'layout':{'title':'Category_Bar!',
                                    'xaxis':{
                                        'title':'Category Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        
        dcc.Graph(
                            id="pie_category",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','labels':objects,'title':'Category Mean',},],
                                'layout':{},
                                'legend':{'x':0,'y':1}
                            
                            }  
                        ),
    ]),

     html.Div([

                dcc.Graph(
                            id="bar_category",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'line'},],
                                'layout':{'title':'Category_Bar!',
                                    'xaxis':{
                                        'title':'Category Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        dcc.Graph(
                            id="donut_category",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','hole':0.7,'labels':objects,'title':'Category Mean',},],
                                'layout':{},
                                'legend':{'x':objects,'y':1}
                            }
                        ),
    ]),      

    html.Div([

                dcc.Graph(
                            id="bar_category",
                            
                            figure={
                                'data':[{'x':performance,
                                'y':objects,
                                'name':'xyz',
                                'orientation':'h',
                                'type':'bar'},],
                                'layout':{'title':'Category_Bar!',
                                    'xaxis':{
                                        'title':'Number of Patients'
                                    },
                                    'yaxis':{
                                        'title':'Category Mean'
                                    }}
                            }
                            
                        ),
            ]),      

])

