import dash
import dash_core_components as dcc
import dash_html_components as html
from django_plotly_dash import DjangoDash
from dash.dependencies import Output,Input
import pandas as pd
import numpy as np

app = DjangoDash('Graph_texture')

dd=pd.read_csv("H:\Project\mini\cancer\\new_data.csv")

text_mean1=dd[dd.texture_mean<10]
text_mean2=dd[dd.texture_mean>=10]
text_mean3=dd[dd.texture_mean>=13]
text_mean4=dd[dd.texture_mean>=16]
text_mean5=dd[dd.texture_mean>=19]
text_mean6=dd[dd.texture_mean>=21]
objects='0-10','10-13','13-16','16-19','19-21','21<'
performance=[len(text_mean1),len(text_mean2),len(text_mean3),len(text_mean4),len(text_mean5),len(text_mean6)]
colors=['gold','yellowgreen','lightcoral','lightskyblue','red','black']
app.layout = html.Div([

    html.Div([

                dcc.Graph(
                            id="bar_texture",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'bar'},],
                                'layout':{'title':'Texture_Bar!',
                                    'xaxis':{
                                        'title':'Texture Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        
        dcc.Graph(
                            id="pie_texture",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','labels':objects,'title':'Texture Mean',},],
                                'layout':{},
                                'legend':{'x':0,'y':1}
                            
                            }  
                        ),
    ]),

     html.Div([

                dcc.Graph(
                            id="bar_texture",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'line'},],
                                'layout':{'title':'Texture_Bar!',
                                    'xaxis':{
                                        'title':'Texture Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        dcc.Graph(
                            id="donut_texture",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','hole':0.7,'labels':objects,'title':'Texture Mean',},],
                                'layout':{},
                                'legend':{'x':objects,'y':1}
                            }
                        ),
    ]),     

    html.Div([

                dcc.Graph(
                            id="bar_texture",
                            
                            figure={
                                'data':[{'x':performance,
                                'y':objects,
                                'name':'xyz',
                                'orientation':'h',
                                'type':'bar'},],
                                'layout':{'title':'Texture_Bar!',
                                    'xaxis':{
                                        'title':'Number of Patients'
                                    },
                                    'yaxis':{
                                        'title':'Texture Mean'
                                    }}
                            }
                            
                        ),
            ]),       

])

