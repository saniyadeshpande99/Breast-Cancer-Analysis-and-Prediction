import dash
import dash_core_components as dcc
import dash_html_components as html
from django_plotly_dash import DjangoDash
from dash.dependencies import Output,Input
import pandas as pd
import numpy as np

app = DjangoDash('Graph_age')

dd=pd.read_csv("H:\Project\mini\cancer\\new_data.csv")

age3=dd[dd.age=='30-39']
age4=dd[dd.age=='40-49']
age5=dd[dd.age=='50-59']
age6=dd[dd.age=='60-69']
age7=dd[dd.age=='70-79']
    
age3m=age3[age3.diagnosis=='M']
age3b=age3[age3.diagnosis=='B']
age4m=age4[age4.diagnosis=='M']
age4b=age4[age4.diagnosis=='B']
age5m=age5[age5.diagnosis=='M']
age5b=age5[age5.diagnosis=='B']
age6m=age6[age6.diagnosis=='M']
age6b=age6[age6.diagnosis=='B']
age7m=age7[age7.diagnosis=='M']
age7b=age7[age7.diagnosis=='B']

objects='30-39','40-49','50-59','60-69','70-79'
performance=[len(age3),len(age4),len(age5),len(age6),len(age7)]
colors=['gold','yellowgreen','lightcoral','lightskyblue','red']
subgroup_names=['M1', 'M2', 'M3', 'M4', 'M5','B1', 'B2', 'B3', 'B4', 'B5']
subgroup_size=[len(age3m),len(age4m),len(age5m),len(age6m),len(age7m),len(age3b),len(age4b),len(age5b),len(age6b),len(age7b)]
     

app.layout = html.Div([

    html.Div([
    
                dcc.Graph(
                            id="barcomp_age",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'bar'},],
                                'layout':{'title':'Age_Bar!',
                                    'xaxis':{
                                        'title':'Age Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        
        dcc.Graph(
                            id="pie_age",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','labels':objects,'title':'Age Mean',},],
                                'layout':{},
                                'legend':{'x':0,'y':1}
                            
                            }  
                        ),
    ]),

     html.Div([

                dcc.Graph(
                            id="bar_age",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'line'},],
                                'layout':{'title':'Age_Bar!',
                                    'xaxis':{
                                        'title':'Age Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        dcc.Graph(
                            id="donut_age",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','hole':0.5,'labels':objects,'title':'Age Mean',},],
                                'layout':{},
                                'legend':{'x':objects,'y':1}
                            }
                        ),
    ]),       

    html.Div([

                dcc.Graph(
                            id="bar_age",
                            
                            figure={
                                'data':[{'x':performance,
                                'y':objects,
                                'name':'xyz',
                                'orientation':'h',
                                'type':'bar'},],
                                'layout':{'title':'Age_Bar!',
                                    'xaxis':{
                                        'title':'Number of Patients'
                                    },
                                    'yaxis':{
                                        'title':'Age Mean'
                                    }}
                            }
                            
                        ),
            ]),

])

