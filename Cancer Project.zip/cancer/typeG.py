import dash
import dash_core_components as dcc
import dash_html_components as html
from django_plotly_dash import DjangoDash
from dash.dependencies import Output,Input
import pandas as pd
import numpy as np

app = DjangoDash('Graph_type')

dd=pd.read_csv("H:\Project\mini\cancer\\new_data.csv")

meno1=dd[dd.menopause=='premeno']
meno2=dd[dd.menopause=='ge40']
meno3=dd[dd.menopause=='lt40']

objects='premeno','ge40','lt40'
performance=[len(meno1),len(meno2),len(meno3)]
colors=['gold','yellowgreen','lightcoral']

app.layout = html.Div([

    html.Div([

                dcc.Graph(
                            id="bar_type",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'bar'},],
                                'layout':{'title':'Type_Bar!',
                                    'xaxis':{
                                        'title':'Type Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        
        dcc.Graph(
                            id="pie_type",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','labels':objects,'title':'Type Mean',},],
                                'layout':{},
                                'legend':{'x':0,'y':1}
                            
                            }  
                        ),
    ]),

     html.Div([

                dcc.Graph(
                            id="bar_type",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'line'},],
                                'layout':{'title':'Type_Bar!',
                                    'xaxis':{
                                        'title':'Type Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        dcc.Graph(
                            id="donut_type",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','hole':0.7,'labels':objects,'title':'Type Mean',},],
                                'layout':{},
                                'legend':{'x':objects,'y':1}
                            }
                        ),
    ]),       

    html.Div([

                dcc.Graph(
                            id="bar_type",
                            
                            figure={
                                'data':[{'x':performance,
                                'y':objects,
                                'name':'xyz',
                                'orientation':'h',
                                'type':'bar'},],
                                'layout':{'title':'Type_Bar!',
                                    'xaxis':{
                                        'title':'Number of Patients'
                                    },
                                    'yaxis':{
                                        'title':'Type Mean'
                                    }}
                            }
                            
                        ),
            ]),     
])

