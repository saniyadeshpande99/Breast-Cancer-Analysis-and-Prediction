from django.urls import path

from . import views
import cancer.dg, cancer.ageG, cancer.areaG, cancer.bqG, cancer.categoryG, cancer.perimeterG, cancer.textureG, cancer.typeG
app_name = 'cancer'
urlpatterns = [
    path('', views.home, name='home'),
    path('analysis/',views.analysis, name='analysis'),
    path('pre/',views.pre, name='pre'),
    path('radius/',views.radius, name='radius'),
    path('age/',views.age, name='age'),
    path('bq/',views.bq, name='bq'),
    path('area/',views.area, name='area'),
    path('category/',views.category, name='category'),
    path('perimeter/',views.perimeter, name='perimeter'),
    path('texture/',views.texture, name='texture'),
    path('type/',views.type, name='type'),
    ]