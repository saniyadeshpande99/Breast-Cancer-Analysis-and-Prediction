
import numpy as np
import pandas as pd
from cancer import sklearn
from sklearn import preprocessing,cross_validation,neighbors

def laptop(float(x1),float(x2),float(x3),float(x4),float(x5),float(x6),float(x7),float(x8),float(x9),float(x10)):
    df=pd.read_csv("H:\Project\mini\cancer\\new_data.csv")

    '''app = DjangoDash('predi')
        
    print("rtert")
    x1=request.form['radius']
    x2=request.form['texture']
    x3=request.form['perimeter']
    x4=request.form['area']
    x5=request.form['smoothness']
    x6=request.form['compactness']
    x7=request.form['concavity']
    x8=request.form['concave_points']
    x9=request.form['symmetry']
    x10=request.form['fractal_dimension']'''
            
    df.drop(['id'],1,inplace=True)
    df.drop(['age'],1,inplace=True)
    df.drop(['menopause'],1,inplace=True)
    df.drop(['breast_quadrent'],1,inplace=True)
            
    X=np.array(df.drop(['diagnosis'],1))
    y=np.array(df['diagnosis'])
            
    X_train,X_test,y_train,y_test=cross_validation.train_test_split(X,y,test_size=0.2)
            
    clf=neighbors.KNeighborsClassifier()
    clf.fit(X_train,y_train)
            
    accuracy=clf.score(X_test,y_test)
    print(accuracy*100)
            
    example_measures=np.array([float(x1),float(x2),float(x3),float(x4),float(x5),float(x6),float(x7),float(x8),float(x9),float(x10)])
    example_measures=example_measures.reshape(1,-1)
            
    prediction=clf.predict(example_measures)
    #ans=prediction
        
    '''print(preprocessing)
    if prediction=="M":
        print("Patient has cancer")
    else:
        print("Patient does not have cancer.")'''
    return prediction