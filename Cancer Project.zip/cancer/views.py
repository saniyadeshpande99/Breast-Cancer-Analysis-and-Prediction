from django.shortcuts import render
from django.http import HttpResponse
import json
import numpy as np
from sklearn import preprocessing,neighbors
from sklearn.model_selection import cross_validate
from sklearn.model_selection import train_test_split
import pandas as pd
import dash
import dash_core_components as dcc
import dash_html_components as html
from django_plotly_dash import DjangoDash
from dash.dependencies import Output,Input

# Create your views here.
def home(request):
	
	return render(request, 'cancer/home.html')

def analysis(request):
	return render(request,'cancer/analysis.html')

def pre(request):

	flag = request.GET['flag']
	df=pd.read_csv("H:\Project\mini\cancer\\new_data.csv")
	app = DjangoDash('predi')
	if(flag == '1'):	
		x1=request.POST['radius']
		x2=request.POST['texture']
		x3=request.POST['perimeter']
		x4=request.POST['area']
		x5=request.POST['smoothness']
		x6=request.POST['compactness']
		x7=request.POST['concavity']
		x8=request.POST['concave_points']
		x9=request.POST['symmetry']
		x10=request.POST['fractal_dimension']
				
		df.drop(['id'],1,inplace=True)
		df.drop(['age'],1,inplace=True)
		df.drop(['menopause'],1,inplace=True)
		df.drop(['breast_quadrent'],1,inplace=True)
				
		X=np.array(df.drop(['diagnosis'],1))
		y=np.array(df['diagnosis'])
				
		X_train, X_test, y_train, y_test=train_test_split(X,y,test_size=0.2)
				
		clf=neighbors.KNeighborsClassifier()
		clf.fit(X_train,y_train)
				
		accuracy=clf.score(X_test,y_test)
		print(accuracy*100)
				
		example_measures=np.array([x1,x2,x3,x4,x5,x6,x7,x8,x9,x10])
		example_measures=example_measures.reshape(1,-1)
				
		prediction=clf.predict(example_measures)
		ans=prediction
			
		if ans=='M':
			result = "Patient has cancer"
		else:
			result = "Patient does not have cancer!"

	else:
		result = ""
	
	result = json.dumps(result)
	input = {'result':result}
	return render(request,'cancer/pre.html', input)

def radius(request):
	return render(request,'cancer/radius.html')

def area(request):
	return render(request,'cancer/area.html')

def age(request):
	return render(request,'cancer/age.html')

def perimeter(request):
	return render(request,'cancer/perimeter.html')

def category(request):
	return render(request,'cancer/category.html')

def texture(request):
	return render(request,'cancer/texture.html')

def type(request):
	return render(request,'cancer/type.html')

def bq(request):
	return render(request,'cancer/bq.html')

def par(request):
	return render(request,'cancer/.html')
	