
    import numpy as np
    from sklearn import preprocessing,cross_validation,neighbors
    import pandas as pd
    df=pd.read_csv("H:\Project\mini\cancer\\new_data.csv")

    app = DjangoDash('predi')
        
    x1=request.POST['radius']
    x2=request.POST['texture']
    x3=request.POST['perimeter']
    x4=request.POST['area']
    x5=request.POST['smoothness']
    x6=request.POST['compactness']
    x7=request.POST['concavity']
    x8=request.POST['concave_points']
    x9=request.POST['symmetry']
    x10=request.POST['fractal_dimension']
            
    df.drop(['id'],1,inplace=True)
    df.drop(['age'],1,inplace=True)
    df.drop(['menopause'],1,inplace=True)
    df.drop(['breast_quadrent'],1,inplace=True)
            
    X=np.array(df.drop(['diagnosis'],1))
    y=np.array(df['diagnosis'])
            
    X_train,X_test,y_train,y_test=cross_validation.train_test_split(X,y,test_size=0.2)
            
    clf=neighbors.KNeighborsClassifier()
    clf.fit(X_train,y_train)
            
    accuracy=clf.score(X_test,y_test)
    print(accuracy*100)
            
    example_measures=np.array([x1,x2,x3,x4,x5,x6,x7,x8,x9,x10])
    example_measures=example_measures.reshape(1,-1)
            
    prediction=clf.predict(example_measures)
    ans=prediction
        
    print(preprocessing)
    if prediction=="M":
        print("Patient has cancer")
    else:
        print("Patient does not have cancer.")