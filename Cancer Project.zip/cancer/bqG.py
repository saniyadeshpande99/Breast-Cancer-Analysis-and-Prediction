import dash
import dash_core_components as dcc
import dash_html_components as html
from django_plotly_dash import DjangoDash
from dash.dependencies import Output,Input
import pandas as pd
import numpy as np

app = DjangoDash('Graph_bq')

dd=pd.read_csv("H:\Project\mini\cancer\\new_data.csv")

brq1=dd[dd.breast_quadrent=='left_up']
brq2=dd[dd.breast_quadrent=='right_up']
brq3=dd[dd.breast_quadrent=='left_low']
brq4=dd[dd.breast_quadrent=='right_low']
brq5=dd[dd.breast_quadrent=='central']

objects='left_up','left_low','central','right_up','right_low'
performance=[len(brq1),len(brq3),len(brq5),len(brq2),len(brq4)]
colors=['yellowgreen','lightcoral','lightskyblue','blue','maroon']

app.layout = html.Div([

    html.Div([

                dcc.Graph(
                            id="bar_bq",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'bar'},],
                                'layout':{'title':'BQ_Bar!',
                                    'xaxis':{
                                        'title':'Breast_Quadrant Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        
        dcc.Graph(
                            id="pie_bq",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','labels':objects,'title':'Breast_Quadrant Mean',},],
                                'layout':{},
                                'legend':{'x':0,'y':1}
                            
                            }  
                        ),
    ]),

     html.Div([

                dcc.Graph(
                            id="bar_bq",
                            
                            figure={
                                'data':[{'x':objects,
                                'y':performance,
                                'name':'xyz',
                                'type':'line'},],
                                'layout':{'title':'Breast_Quadrant_Bar!',
                                    'xaxis':{
                                        'title':'Breast_Quadrant Mean'
                                    },
                                    'yaxis':{
                                        'title':'Number of Patients'
                                    }}
                            }
                            
                        ),
            ]),

    html.Div([
        dcc.Graph(
                            id="donut_area",
                            
                            figure={
                                'data':[{'values':performance,'type':'pie','hole':0.7,'labels':objects,'title':'Breast_Quadrant Mean',},],
                                'layout':{},
                                'legend':{'x':objects,'y':1}
                            }
                        ),
    ]),       

    html.Div([

                dcc.Graph(
                            id="bar_bq",
                            
                            figure={
                                'data':[{'x':performance,
                                'y':objects,
                                'name':'xyz',
                                'orientation':'h',
                                'type':'bar'},],
                                'layout':{'title':'Area_BQ!',
                                    'xaxis':{
                                        'title':'Number of Patients'
                                    },
                                    'yaxis':{
                                        'title':'BQ Mean'
                                    }}
                            }
                            
                        ),
            ]),     

])

